﻿using Prometheus;
using Server2.Models;

namespace Server2.Services
{
    public class ServerMetricsService
    {
        private readonly List<ServerState> _pattern;
        private int _currentIndex;
        private readonly Gauge _cpuUsage = Metrics.CreateGauge("server_cpu_usage", "CPU Usage");
        private readonly Gauge _activeRequests = Metrics.CreateGauge("server_active_requests", "Active Requests");
        private readonly Gauge _responseTime = Metrics.CreateGauge("server_response_time_ms", "Response Time (ms)");
        private readonly Gauge _failureRate = Metrics.CreateGauge("server_failure_rate", "Failure Rate");
        private readonly object _lock = new();

        public ServerMetricsService()
        {
            // Гірший сервер: більший CPU і більше запитів, ближчий до порогу
            _pattern = new List<ServerState>
            {
                /*new ServerState { CpuUsage = 60, ActiveRequests = 20, TotalRequests = 20, ResponseTime = 150, FailureRate = 0.10, IsAvailable = true },
                new ServerState { CpuUsage = 75, ActiveRequests = 25, TotalRequests = 40, ResponseTime = 200, FailureRate = 0.15, IsAvailable = true },
                new ServerState { CpuUsage = 85, ActiveRequests = 30, TotalRequests = 70, ResponseTime = 250, FailureRate = 0.20, IsAvailable = true },
                new ServerState { CpuUsage = 90, ActiveRequests = 35, TotalRequests = 100,ResponseTime = 300, FailureRate = 0.30, IsAvailable = false },*/

                new ServerState { CpuUsage = 96, ActiveRequests = 10, TotalRequests = 25, ResponseTime = 300, FailureRate = 0.40, IsAvailable = false },
                new ServerState { CpuUsage = 98, ActiveRequests = 10, TotalRequests = 55, ResponseTime = 350, FailureRate = 0.50, IsAvailable = false },
                new ServerState { CpuUsage = 100,ActiveRequests = 10, TotalRequests = 90, ResponseTime = 400, FailureRate = 0.60, IsAvailable = false },
                new ServerState { CpuUsage = 90, ActiveRequests = 10, TotalRequests =120, ResponseTime = 250, FailureRate = 0.45, IsAvailable = false },
                new ServerState { CpuUsage = 10, ActiveRequests =  11, TotalRequests =  5, ResponseTime =  50, FailureRate = 0.01, IsAvailable = true },
                new ServerState { CpuUsage = 20, ActiveRequests = 11, TotalRequests = 15, ResponseTime =  60, FailureRate = 0.02, IsAvailable = true },
                new ServerState { CpuUsage = 50, ActiveRequests = 11, TotalRequests = 30, ResponseTime = 100, FailureRate = 0.05, IsAvailable = true },
                new ServerState { CpuUsage = 15, ActiveRequests = 11, TotalRequests = 40, ResponseTime =  70, FailureRate = 0.03, IsAvailable = true },
                new ServerState { CpuUsage = 95, ActiveRequests = 10, TotalRequests = 25, ResponseTime = 300, FailureRate = 0.40, IsAvailable = false },
                new ServerState { CpuUsage = 98, ActiveRequests = 10, TotalRequests = 55, ResponseTime = 350, FailureRate = 0.50, IsAvailable = false },
                new ServerState { CpuUsage = 100,ActiveRequests = 10, TotalRequests = 90, ResponseTime = 400, FailureRate = 0.60, IsAvailable = false },
                new ServerState { CpuUsage = 90, ActiveRequests = 10, TotalRequests =120, ResponseTime = 250, FailureRate = 0.45, IsAvailable = false },
                
            };
            _currentIndex = 0;

            new Timer(_ =>
            {
                LogNextPattern();
            }, null, 0, 5000);
        }

        private void LogNextPattern()
        {
            ServerState next;
            lock (_lock)
            {
                next = _pattern[_currentIndex];
                _currentIndex = (_currentIndex + 1) % _pattern.Count;
            }

            _cpuUsage.Set(next.CpuUsage);
            _activeRequests.Set(next.ActiveRequests);
            _responseTime.Set(next.ResponseTime);
            _failureRate.Set(next.FailureRate);
        }

        public ServerState GetServerState()
        {
            lock (_lock)
            {
                return new ServerState
                {
                    CpuUsage = (int)_cpuUsage.Value,
                    ActiveRequests = (int)_activeRequests.Value,
                    TotalRequests = (int)(_activeRequests.Value),
                    ResponseTime = (int)_responseTime.Value,
                    FailureRate = _failureRate.Value,
                    IsAvailable = _failureRate.Value < 0.25 // наприклад, якщо failRate>0.25, server недоступний
                };
            }
        }
    }
}


