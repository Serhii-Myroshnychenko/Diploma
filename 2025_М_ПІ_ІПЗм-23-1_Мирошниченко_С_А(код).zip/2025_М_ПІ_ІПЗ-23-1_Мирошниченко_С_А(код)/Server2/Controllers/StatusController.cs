﻿using Microsoft.AspNetCore.Mvc;
using Server2.Services;
using Server2.Models;

namespace Server2.Controllers
{
    [ApiController]
    [Route("api/status")]
    public class StatusController : ControllerBase
    {
        private readonly ServerMetricsService _metricsService;

        public StatusController(ServerMetricsService metricsService)
        {
            _metricsService = metricsService;
        }

        [HttpGet]
        public ActionResult<ServerState> GetStatus()
        {
            return Ok(_metricsService.GetServerState());
        }
    }
}

