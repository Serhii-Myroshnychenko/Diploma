﻿    using DistLoad.Interfaces;
    using DistLoad.Models;

namespace DistLoad.Services
{
    public class AdaptiveBalancer : ILoadBalancer
    {
        private readonly List<ServerInstance> _servers;
        private const double Epsilon = 0.001;

        public AdaptiveBalancer(List<ServerInstance> servers)
        {
            _servers = servers;
        }

        public Task<ServerInstance> GetNextServerAsync()
        {
            if (_servers.Count == 0)
                throw new Exception("No available servers");

            var candidates = _servers
                .Where(s => s.IsOnline && s.IsAvailable && !s.IsOverloaded)
                .ToList();

            if (!candidates.Any())
                throw new Exception("No available servers");


            var scored = candidates.Select(s =>
            {
                // вважатимемо, що кожен сервер має 1 віртуальне ядро і 1 ГБ пам’яті:
                double Ci = 1.0;
                double Mi = 1.0;

                // Для AvgResponseTime беремо зі Status (якщо немає – беремо заглушку 1 ms)
                double avgResp = (s.LastState?.ResponseTime ?? 1);
                // Для FailureRate беремо зі Status (якщо немає – 0.0)
                double failRate = (s.LastState?.FailureRate ?? 0.0);

                // Використовуємо формулу (2):
                double denom = Math.Log(avgResp + 1) + Math.Log(failRate + 1);
                double weight = (Ci * Mi) / (denom + Epsilon);

                // Обчислюємо Score (1):
                double ar = s.ActiveRequests;
                double cpu = s.CpuUsage;
                double total = s.RequestCount;
                double resp = (s.LastState?.ResponseTime ?? 1);

                double numerator =
                    Math.Log(ar + 1) +
                    Math.Log(cpu + 1) +
                    Math.Log(total + 1) +
                    Math.Log(resp + 1);

                double score = numerator / (weight + Epsilon);

                return new { Server = s, Score = score };
            })
            .OrderBy(x => x.Score)
            .ToList();

            var bestServer = scored.First().Server;

            // Як тільки обрали – збільшуємо лічильник активних запитів,
            // аби на наступному виклику вибір врахував це
            bestServer.ActiveRequests++;
            return Task.FromResult(bestServer);
        }

        public void ReleaseServer(ServerInstance server)
        {
            var target = _servers.FirstOrDefault(s => s.Id == server.Id);
            if (target != null && target.ActiveRequests > 0)
            {
                target.ActiveRequests--;
            }
        }

        public List<ServerInstance> GetServers() => _servers;
    }
}

