﻿namespace DistLoad.Models
{
    public class ServerState
    {
        public int CpuUsage { get; set; }
        public int ActiveRequests { get; set; }
        public int TotalRequests { get; set; }
        public bool IsAvailable { get; set; }
        public int ResponseTime { get; set; }
        public double FailureRate { get; set; }
    }
}
