﻿using Microsoft.AspNetCore.Mvc;
using Server3.Services;
using Server3.Models;

namespace Server3.Controllers
{
    [ApiController]
    [Route("api/status")]
    public class StatusController : ControllerBase
    {
        private readonly ServerMetricsService _metricsService;

        public StatusController(ServerMetricsService metricsService)
        {
            _metricsService = metricsService;
        }

        [HttpGet]
        public ActionResult<ServerState> GetStatus()
        {
            return Ok(_metricsService.GetServerState());
        }
    }
}

