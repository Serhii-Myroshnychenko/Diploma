﻿using Microsoft.AspNetCore.Mvc;
using Server1.Services;
using Server1.Models;

namespace Server1.Controllers
{
    [ApiController]
    [Route("api/status")]
    public class StatusController : ControllerBase
    {
        private readonly ServerMetricsService _metricsService;

        public StatusController(ServerMetricsService metricsService)
        {
            _metricsService = metricsService;
        }

        [HttpGet]
        public ActionResult<ServerState> GetStatus()
        {
            return Ok(_metricsService.GetServerState());
        }
    }
}

