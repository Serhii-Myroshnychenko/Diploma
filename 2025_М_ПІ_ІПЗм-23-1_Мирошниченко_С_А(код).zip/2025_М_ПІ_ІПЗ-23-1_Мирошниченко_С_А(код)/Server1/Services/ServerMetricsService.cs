﻿using Prometheus;
using Server1.Models;
namespace Server1.Services
{
    public class ServerMetricsService
    {
        private readonly List<ServerState> _pattern;
        private int _currentIndex;
        private readonly Gauge _cpuUsage = Metrics.CreateGauge("server_cpu_usage", "CPU Usage");
        private readonly Gauge _activeRequests = Metrics.CreateGauge("server_active_requests", "Active Requests");
        private readonly Gauge _responseTime = Metrics.CreateGauge("server_response_time_ms", "Response Time (ms)");
        private readonly Gauge _failureRate = Metrics.CreateGauge("server_failure_rate", "Failure Rate");
        private readonly object _lock = new();

        public ServerMetricsService()
        {
            // Цей патерн описує “поведінку” Server1 (гарні значення)
            _pattern = new List<ServerState>
            {
                /*new ServerState { CpuUsage = 10, ActiveRequests =  5, TotalRequests =  5, ResponseTime =  50, FailureRate = 0.01, IsAvailable = true },
                new ServerState { CpuUsage = 20, ActiveRequests = 10, TotalRequests = 15, ResponseTime =  60, FailureRate = 0.02, IsAvailable = true },
                new ServerState { CpuUsage = 50, ActiveRequests = 15, TotalRequests = 30, ResponseTime = 100, FailureRate = 0.05, IsAvailable = true },
                new ServerState { CpuUsage = 15, ActiveRequests =  7, TotalRequests = 40, ResponseTime =  70, FailureRate = 0.03, IsAvailable = true },*/

                new ServerState { CpuUsage = 11, ActiveRequests =  11, TotalRequests =  5, ResponseTime =  50, FailureRate = 0.01, IsAvailable = true },
                new ServerState { CpuUsage = 20, ActiveRequests = 11, TotalRequests = 15, ResponseTime =  60, FailureRate = 0.02, IsAvailable = true },
                new ServerState { CpuUsage = 50, ActiveRequests = 11, TotalRequests = 30, ResponseTime = 100, FailureRate = 0.05, IsAvailable = true },
                new ServerState { CpuUsage = 15, ActiveRequests =  11, TotalRequests = 40, ResponseTime =  70, FailureRate = 0.03, IsAvailable = true },
                new ServerState { CpuUsage = 95, ActiveRequests = 10, TotalRequests = 25, ResponseTime = 300, FailureRate = 0.40, IsAvailable = false },
                new ServerState { CpuUsage = 98, ActiveRequests = 10, TotalRequests = 55, ResponseTime = 350, FailureRate = 0.50, IsAvailable = false },
                new ServerState { CpuUsage = 100,ActiveRequests = 10, TotalRequests = 90, ResponseTime = 400, FailureRate = 0.60, IsAvailable = false },
                new ServerState { CpuUsage = 90, ActiveRequests = 10, TotalRequests =120, ResponseTime = 250, FailureRate = 0.45, IsAvailable = false },
                new ServerState { CpuUsage = 95, ActiveRequests = 10, TotalRequests = 25, ResponseTime = 300, FailureRate = 0.40, IsAvailable = false },
                new ServerState { CpuUsage = 98, ActiveRequests = 10, TotalRequests = 55, ResponseTime = 350, FailureRate = 0.50, IsAvailable = false },
                new ServerState { CpuUsage = 100,ActiveRequests = 10, TotalRequests = 90, ResponseTime = 400, FailureRate = 0.60, IsAvailable = false },
                new ServerState { CpuUsage = 90, ActiveRequests = 10, TotalRequests =120, ResponseTime = 250, FailureRate = 0.45, IsAvailable = false },
            };
            _currentIndex = 0;

            new Timer(_ =>
            {
                LogNextPattern();
            }, null, 0, 5000);
        }

        private void LogNextPattern()
        {
            ServerState next;
            lock (_lock)
            {
                next = _pattern[_currentIndex];
                _currentIndex = (_currentIndex + 1) % _pattern.Count;
            }

            _cpuUsage.Set(next.CpuUsage);
            _activeRequests.Set(next.ActiveRequests);
            _responseTime.Set(next.ResponseTime);
            _failureRate.Set(next.FailureRate);
        }

        public ServerState GetServerState()
        {
            lock (_lock)
            {
                return new ServerState
                {
                    CpuUsage = (int)_cpuUsage.Value,
                    ActiveRequests = (int)_activeRequests.Value,
                    TotalRequests = (int)(_activeRequests.Value), // тут можна окремий лічильник
                    ResponseTime = (int)_responseTime.Value,
                    FailureRate = _failureRate.Value,
                    IsAvailable = true
                };
            }
        }
    }
}
